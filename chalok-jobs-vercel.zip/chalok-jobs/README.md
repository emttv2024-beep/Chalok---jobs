# চালক জবস (Chalok Jobs)

ড্রাইভার নিয়োগের জন্য বাংলাদেশের সেরা জব পোর্টাল।

## Vercel-এ পাবলিশ করার ধাপ

### ধাপ ১ — GitHub অ্যাকাউন্ট
- github.com গিয়ে ফ্রি অ্যাকাউন্ট খুলুন

### ধাপ ২ — নতুন Repository বানান
- GitHub-এ লগইন করুন
- "New repository" ক্লিক করুন
- নাম দিন: chalok-jobs
- "Create repository" ক্লিক করুন

### ধাপ ৩ — ফাইল আপলোড করুন
- এই ZIP ফাইলের ভেতরের সব ফাইল GitHub-এ আপলোড করুন
- "Upload files" বাটন দিয়ে সব ফোল্ডার সহ আপলোড করুন
- "Commit changes" ক্লিক করুন

### ধাপ ৪ — Vercel-এ Deploy করুন
- vercel.com গিয়ে GitHub দিয়ে লগইন করুন
- "New Project" ক্লিক করুন
- chalok-jobs repository বেছে নিন
- "Deploy" ক্লিক করুন
- ২ মিনিটের মধ্যে লিংক পাবেন!

## আপনার সাইটের লিংক হবে
https://chalok-jobs.vercel.app
